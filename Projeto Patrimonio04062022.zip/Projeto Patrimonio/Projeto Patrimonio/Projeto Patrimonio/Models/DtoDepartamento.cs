﻿namespace Projeto_Patrimonio.Models
{
    public class DtoDepartamento
    {
        public int id { get; set; }
        public string nomedepartamento { get; set; }
        public string descricaodepartamento { get; set; }
        public string nomelocal { get; set; }
    }
}
